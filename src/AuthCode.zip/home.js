import React, { Component } from 'react';

class Home extends Component{
	render(){
		return (
			<div>
				<h2>
					Click button for Login or Registrate
				</h2>
			</div>
			);
	}
}
export default Home;