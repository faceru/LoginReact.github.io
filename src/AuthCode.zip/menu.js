import React, { Component } from 'react';
import './App.css';
import {BrowserRouter, Route, Link} from 'react-router-dom';
import createBrowserHistory from 'history/createBrowserHistory';
import Registrate from './registrate';
import Login from './login';
import Home from './home';

const history = createBrowserHistory();

class Menu extends Component {
  render() {
    return (
    	<BrowserRouter history={history}>
    		<div>
    			<ul className="menu">
    				<li className="menu-item">
    					<Link to='/' className="btn btn-primary">
    						Home
    					</Link>
    				</li>
    				<li className="menu-item">
    					<Link to='/Login' className="btn btn-primary">
    						Login
    					</Link>
    				</li>
    				<li className="menu-item">
    					<Link to='/Registrate' className="btn btn-primary">
    						Registrate
    					</Link>
    				</li>
    			</ul>
    			<hr/>
    			<Route exact path='/' component={Home}/>
    			<Route path='/Login' component={Login}/>
    			<Route path='/Registrate' component={Registrate}/>
    		</div>
    	</BrowserRouter>
   );
  }
}

export default Menu;